document.getElementById('symptom-form').addEventListener('submit', function (e) {
  e.preventDefault();
  document.getElementById('loading').classList.remove('hidden');
  document.getElementById('result').classList.add('hidden');
  document.getElementById('no-match').classList.add('hidden');
  const symptomsInput = document.getElementById('symptoms-input').value;
  fetch('/api/symptoms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ symptoms: symptomsInput })
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById('loading').classList.add('hidden');
    if (data.match) {
      document.getElementById('illness').textContent = data.illness;
      document.getElementById('first-aid').textContent = data.firstAid;
      document.getElementById('medications').innerHTML = data.medications.map(med => `<li>${med}</li>`).join('');
      document.getElementById('doctor-advice').textContent = data.doctorAdvice;
      document.getElementById('result').classList.remove('hidden');
    } else {
      document.getElementById('no-match').classList.remove('hidden');
    }
  });
});