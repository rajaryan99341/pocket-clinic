const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

const symptomData = {
  "fever headache sore throat": {
    illness: "Viral Fever",
    firstAid: "Stay hydrated, rest, and take paracetamol.",
    medications: ["Paracetamol 500mg", "ORS Sachet"],
    doctorAdvice: "If fever exceeds 102°F for 2+ days, visit a doctor."
  },
  "cough sore throat": {
    illness: "Common Cold",
    firstAid: "Rest, drink warm fluids, use a throat lozenge.",
    medications: ["Cough Syrup", "Paracetamol 500mg"],
    doctorAdvice: "If cough persists for more than 2 weeks, consult a doctor."
  },
  "headache": {
    illness: "Tension Headache",
    firstAid: "Rest in a quiet place, hydrate, and take pain relievers.",
    medications: ["Ibuprofen 200mg", "Paracetamol 500mg"],
    doctorAdvice: "If headaches are frequent or severe, see a doctor."
  }
};

app.post('/api/symptoms', (req, res) => {
  const inputSymptoms = req.body.symptoms.toLowerCase().split(',').map(s => s.trim());
  let matchFound = false;
  for (let key in symptomData) {
    const keySymptoms = key.split(' ');
    if (inputSymptoms.every(symptom => keySymptoms.includes(symptom))) {
      res.json({ match: true, ...symptomData[key] });
      matchFound = true;
      break;
    }
  }
  if (!matchFound) {
    res.json({ match: false });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});